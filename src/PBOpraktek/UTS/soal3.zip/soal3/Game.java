package PBOpraktek.UTS.soal3;

public class Game {
    Piece [][] board;

    // constructor
    // membuat board kosong
    public Game(){
        board = new Piece[8][8];
    }

}
