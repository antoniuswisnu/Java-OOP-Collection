package PBOpraktek.UTS.soal1;

public class Main {
    public static void main(String[] args){
        Pegawai a = new Pegawai("Rio","Back-End","Intern");
        Pegawai b = new Pegawai("Alif","Back-End","Programmer");
        Pegawai c = new Pegawai("Melani", "Front-End", "Intern");
        Pegawai d = new Pegawai("Lintang", "Back-End", "Programmer");
        Pegawai e = new Pegawai("Alya", "Front-End", "Intern");

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
    }
}
